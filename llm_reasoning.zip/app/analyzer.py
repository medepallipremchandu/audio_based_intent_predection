from app.whisper_service import transcribe_audio
from app.gpt_service import analyze_transcript
from app.recommendation_engine import generate_recommendations


def analyze_call(audio_path):

    transcript = transcribe_audio(audio_path)

    analysis = analyze_transcript(transcript)

    features = {
        "student_questions_count": analysis["student_questions_count"],
        "student_objections_count": analysis["student_objections_count"],
        "positive_statements": analysis["positive_statements"],
        "negative_statements": analysis["negative_statements"],
        "budget_mentions": analysis["budget_mentions"],
        "parent_mentions": analysis["parent_mentions"],
        "course_mentions": analysis["course_mentions"],
        "deadline_interest": analysis["deadline_interest"],
    }

    recommendations = generate_recommendations(
        features,
        analysis["objections"]
    )

    analysis["features"] = features
    analysis["recommendations"] = recommendations
    analysis["transcript"] = transcript

    return analysis